#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;
unordered_map<string, bool> memo;
bool isScrambleHelper(string& s1, string& s2, int i1, int i2, int length) {
    string key = to_string(i1) + "-" + to_string(i2) + "-" + to_string(length);
    if (memo.find(key) != memo.end()) {
        return memo[key];
    }
    if (s1.substr(i1, length) == s2.substr(i2, length)) {
        memo[key] = true;
        return true;
    }
    int count[26] = {0};
    for (int i = 0; i < length; ++i) {
        count[s1[i1 + i] - 'a']++;
        count[s2[i2 + i] - 'a']--;
    }
    for (int i = 0; i < 26; ++i) {
        if (count[i] != 0) {
            memo[key] = false;
            return false;
        }
    }
    for (int split = 1; split < length; ++split) {
        if ((isScrambleHelper(s1, s2, i1, i2, split) && isScrambleHelper(s1, s2, i1 + split, i2 + split, length - split)) ||
            (isScrambleHelper(s1, s2, i1, i2 + length - split, split) && isScrambleHelper(s1, s2, i1 + split, i2, length - split))) {
            memo[key] = true;
            return true;
        }
    }
    memo[key] = false;
    return false;
}
bool isScramble(string s1, string s2) {
    int n = s1.length();
    if (n != s2.length()) {
        return false;
    }
    return isScrambleHelper(s1, s2, 0, 0, n);
}
int main() {
    string s1 = "great";
    string s2 = "rgeat";
    if (isScramble(s1, s2)) {
        cout << "The second string is a scrambled string of the first string." << endl;
    } else {
        cout << "The second string is not a scrambled string of the first string." << endl;
    }
    return 0;
}
