#include <iostream>
#include <vector>
using namespace std;
string getPermutation(int n, int k) {
    vector<int> factorial(n, 1);
    vector<int> numbers(n);
    string result;
    for (int i = 1; i < n; ++i) {
        factorial[i] = factorial[i - 1] * i;
    }
    for (int i = 0; i < n; ++i) {
        numbers[i] = i + 1;
    }
    k--; 
    for (int i = n - 1; i >= 0; --i) {
        int index = k / factorial[i];
        result += to_string(numbers[index]);
        numbers.erase(numbers.begin() + index);
        k -= index * factorial[i];
    }
    return result;
}
int main() {
    int n = 3;
    int k = 3;
    cout << "The " << k << "th permutation sequence for n=" << n << " is: " << getPermutation(n, k) << endl;
    return 0;
}
