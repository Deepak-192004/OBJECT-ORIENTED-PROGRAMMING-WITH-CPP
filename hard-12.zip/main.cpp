#include <iostream>
#include <vector>
using namespace std;
bool isValid(vector<int>& queens, int row, int col) {
    for (int i = 0; i < row; ++i) {
        if (queens[i] == col || abs(row - i) == abs(col - queens[i])) {
            return false;
        }
    }
    return true;
}
void solveNQueens(int& count, vector<int>& queens, int row, int n) {
    if (row == n) {
        count++;
        return;
    }
    for (int col = 0; col < n; ++col) {
        if (isValid(queens, row, col)) {
            queens[row] = col;
            solveNQueens(count, queens, row + 1, n);
        }
    }
}
int totalNQueens(int n) {
    int count = 0;
    vector<int> queens(n, -1); 
    solveNQueens(count, queens, 0, n);
    return count;
}
int main() {
    int n = 4; 
    int distinctSolutions = totalNQueens(n);
    cout << "Number of distinct solutions to the N-Queens puzzle: " << distinctSolutions << endl;
    return 0;
}
