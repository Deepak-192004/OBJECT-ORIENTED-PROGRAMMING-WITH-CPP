#include <iostream>
#include <vector>
#include <string>
using namespace std;
string justifyLine(vector<string>& words, int maxWidth, int start, int end, bool lastLine) {
    int numWords = end - start + 1;
    int totalLength = 0;
    for (int i = start; i <= end; ++i) {
        totalLength += words[i].length();
    }
    int totalSpaces = maxWidth - totalLength;
    int numGaps = numWords - 1;
    string result = "";
    if (lastLine || numWords == 1) {
        for (int i = start; i <= end; ++i) {
            result += words[i];
            if (i < end) result += " ";
        }
        result += string(maxWidth - result.length(), ' ');
    } else {
        int baseSpaces = totalSpaces / numGaps;
        int extraSpaces = totalSpaces % numGaps;
        for (int i = start; i <= end; ++i) {
            result += words[i];
            if (i < end) {
                int spaces = baseSpaces + (i - start < extraSpaces ? 1 : 0);
                result += string(spaces, ' ');
            }
        }
    }
    return result;
}
vector<string> fullJustify(vector<string>& words, int maxWidth) {
    vector<string> result;
    int n = words.size();
    int start = 0, end = 0, currentWidth = 0;
    
    while (start < n) {
        currentWidth = words[start].length();
        end = start + 1;
        while (end < n && currentWidth + 1 + words[end].length() <= maxWidth) {
            currentWidth += 1 + words[end].length();
            ++end;
        }
        bool lastLine = (end == n);
        result.push_back(justifyLine(words, maxWidth, start, end - 1, lastLine));
        start = end;
    }
    return result;
}
int main() {
    vector<string> words = {"This", "is", "an", "example", "of", "text", "justification."};
    int maxWidth = 16;
    vector<string> justifiedText = fullJustify(words, maxWidth);
    cout << "Justified text:" << endl;
    for (const string& line : justifiedText) {
        cout << line << endl;
    }
    return 0;
}
