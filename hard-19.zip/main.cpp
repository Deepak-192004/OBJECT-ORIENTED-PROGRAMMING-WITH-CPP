#include <iostream>
#include <vector>
#include <stack>
using namespace std;
int maximalRectangle(vector<vector<char>>& matrix) {
    if (matrix.empty()) return 0;
    int maxArea = 0;
    int rows = matrix.size();
    int cols = matrix[0].size();
    vector<int> heights(cols, 0); 
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            heights[j] = (matrix[i][j] == '1') ? heights[j] + 1 : 0;
        }
        stack<int> s;
        for (int j = 0; j <= cols; ++j) {
            while (!s.empty() && (j == cols || heights[j] < heights[s.top()])) {
                int height = heights[s.top()];
                s.pop();
                int width = s.empty() ? j : j - s.top() - 1;
                maxArea = max(maxArea, height * width);
            }
            s.push(j);
        }
    }
    return maxArea;
}
int main() {
    vector<vector<char>> matrix = {
        {'1', '0', '1', '0', '0'},
        {'1', '0', '1', '1', '1'},
        {'1', '1', '1', '1', '1'},
        {'1', '0', '0', '1', '0'}
    };
    int maxRectangleArea = maximalRectangle(matrix);
    cout << "Area of the largest rectangle in the binary matrix: " << maxRectangleArea << endl;
    return 0;
}
