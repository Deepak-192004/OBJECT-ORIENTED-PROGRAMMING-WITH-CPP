#include <iostream>
#include <stack>
using namespace std;
int longestValidParentheses(string s) {
    stack<int> st;
    st.push(-1);
    int maxLen = 0;
    for (int i = 0; i < s.size(); ++i) {
        if (s[i] == '(') {
            st.push(i);
        } else { // s[i] == ')'
            st.pop();
            if (!st.empty()) {
                maxLen = max(maxLen, i - st.top());
            } else {
                st.push(i); 
            }
        }
    }
    return maxLen;
}
int main() {
    string s = "(()))())("; 
    int length = longestValidParentheses(s);
    cout << "Length of the longest valid parentheses substring: " << length << endl;
    return 0;
}
