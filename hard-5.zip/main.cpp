#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
vector<int> findSubstring(string s, vector<string>& words) {
    vector<int> result;
    if (s.empty() || words.empty()) {
        return result;
    }
    int wordLen = words[0].size();
    int wordCount = words.size();
    int concatLen = wordLen * wordCount;

    unordered_map<string, int> wordFreq;
    for (const string& word : words) {
        wordFreq[word]++;
    }
    for (int i = 0; i <= (int)s.size() - concatLen; ++i) {
        unordered_map<string, int> seen;
        int j = 0;
        while (j < wordCount) {
            string word = s.substr(i + j * wordLen, wordLen);
            if (wordFreq.find(word) != wordFreq.end()) {
                seen[word]++;
                if (seen[word] > wordFreq[word]) {
                    break;
                }
            } else {
                break;
            }
            j++;
        }
        if (j == wordCount) {
            result.push_back(i);
        }
    }
    return result;
}
int main() {
    string s = "barfoothefoobarman";
    vector<string> words = {"foo", "bar"};
    vector<int> indices = findSubstring(s, words);
    cout << "Starting indices of concatenated substrings: ";
    for (int index : indices) {
        cout << index << " ";
    }
    cout << endl;
    return 0;
}
